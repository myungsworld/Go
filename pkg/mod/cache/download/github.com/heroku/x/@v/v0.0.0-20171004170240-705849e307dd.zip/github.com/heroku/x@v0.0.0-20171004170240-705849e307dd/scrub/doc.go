// Package scrub defines helpers for removing sensitive data from HTTP headers
// and URLs to make them safe for logging.
package scrub
