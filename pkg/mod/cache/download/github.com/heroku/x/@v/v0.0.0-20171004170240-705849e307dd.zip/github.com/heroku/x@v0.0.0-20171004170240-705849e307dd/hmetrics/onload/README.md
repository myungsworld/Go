runtime-metrics
===============

This will only be useful if you are inside the runtime metrics private beta.

This package, once loaded, will implicitly dump a subset of runtime performace
metrics to the URL denoted by `HEROKU_METRICS_URL`
