/*
package hmetrics is a self-contained client for heroku Go runtime metrics.
*/

package hmetrics
